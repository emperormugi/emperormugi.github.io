import { useEffect, useState } from "react";
import { toast } from "sonner";
import { macroMismatch, parseAmount } from "@/lib/macro/calc";
import { isValidDateKey, isValidTime, nowTime } from "@/lib/macro/dates";
import { actions } from "@/lib/macro/store";
import type { Meal, Template } from "@/lib/macro/types";
import { Sheet } from "./Sheet";

const NUM_FIELDS = [
  ["calories", "Calories (kcal)"],
  ["protein", "Protein (g)"],
  ["carbs", "Carbs (g)"],
  ["fat", "Fat (g)"],
  ["fiber", "Fiber (g)"],
] as const;
type NumKey = (typeof NUM_FIELDS)[number][0];

type Form = { name: string; date: string; time: string; notes: string } & Record<NumKey, string>;

const str = (n: number) => String(n);

export function MealForm({
  open,
  onOpenChange,
  date,
  editing,
  templates,
  onDateSaved,
  prefill = null,
}: {
  prefill?: Template | null;
  open: boolean;
  onOpenChange: (o: boolean) => void;
  date: string;
  editing: Meal | null;
  templates: Template[];
  onDateSaved: (date: string) => void;
}) {
  const [f, setF] = useState<Form>(blank(date));
  const [tried, setTried] = useState(false);
  const [saving, setSaving] = useState(false);
  const [savingTemplate, setSavingTemplate] = useState(false);

  useEffect(() => {
    if (!open) return;
    setTried(false);
    setF(
      editing
        ? {
            name: editing.name, date: editing.date, time: editing.time, notes: editing.notes,
            calories: str(editing.calories), protein: str(editing.protein), carbs: str(editing.carbs),
            fat: str(editing.fat), fiber: str(editing.fiber),
          }
        : prefill
          ? { ...blank(date), name: prefill.name, notes: prefill.notes, calories: str(prefill.calories),
              protein: str(prefill.protein), carbs: str(prefill.carbs), fat: str(prefill.fat), fiber: str(prefill.fiber) }
          : blank(date),
    );
  }, [open, editing, date, prefill]);

  const nums = Object.fromEntries(NUM_FIELDS.map(([k]) => [k, parseAmount(f[k])])) as Record<NumKey, number | null>;
  const errors = {
    name: !f.name.trim(),
    date: !isValidDateKey(f.date),
    time: !isValidTime(f.time),
    ...Object.fromEntries(NUM_FIELDS.map(([k]) => [k, nums[k] === null])),
  } as Record<string, boolean>;
  const valid = !Object.values(errors).some(Boolean);
  const mismatch = valid && macroMismatch(nums as Record<NumKey, number>);

  const set = (k: keyof Form) => (e: { target: { value: string } }) => setF((p) => ({ ...p, [k]: e.target.value }));

  const applyTemplate = (id: string) => {
    const t = templates.find((x) => x.id === id);
    if (!t) return;
    setF((p) => ({
      ...p, name: t.name, notes: t.notes, calories: str(t.calories), protein: str(t.protein),
      carbs: str(t.carbs), fat: str(t.fat), fiber: str(t.fiber),
    }));
  };

  const save = async () => {
    setTried(true);
    if (!valid || saving) return;
    setSaving(true);
    const input = {
      name: f.name.trim(), date: f.date, time: f.time, notes: f.notes.trim(),
      ...(nums as Record<NumKey, number>),
    };
    try {
      if (editing) await actions.updateMeal(editing.id, input);
      else await actions.addMeal(input);
      onDateSaved(f.date);
      onOpenChange(false);
      toast.success(editing ? "Meal updated" : "Meal saved");
    } catch {
      toast.error("Couldn't save — your device storage may be full.");
    } finally {
      setSaving(false);
    }
  };

  const saveAsTemplate = async () => {
    setTried(true);
    if (!valid || savingTemplate) return;
    setSavingTemplate(true);
    try {
      await actions.addTemplate({ name: f.name.trim(), notes: f.notes.trim(), ...(nums as Record<NumKey, number>) });
      toast.success("Added to Saved Meals");
    } catch {
      toast.error("Couldn't save this reusable meal. Please try again.");
    } finally {
      setSavingTemplate(false);
    }
  };



  const inv = (k: string) => (tried && errors[k] ? "true" : undefined);

  return (
    <Sheet
      open={open}
      onOpenChange={onOpenChange}
      title={editing ? "Edit meal" : "Add meal"}
      footer={
        <div className="flex gap-2">
          <button className="btn-ml btn-ghost flex-1" onClick={() => onOpenChange(false)}>Cancel</button>
          <button className="btn-ml btn-primary flex-[2]" onClick={save} disabled={saving}>
            {editing ? "Save changes" : "Save meal"}
          </button>
        </div>
      }
    >
      <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); save(); }}>
        {!editing && templates.length > 0 && (
          <label className="block space-y-1">
            <span className="label-ml">Start from saved meal</span>
            <select className="field-ml" value="" onChange={(e) => applyTemplate(e.target.value)}>
              <option value="">Choose…</option>
              {templates.map((t) => <option key={t.id} value={t.id}>{t.name} · {Math.round(t.calories)} kcal</option>)}
            </select>
          </label>
        )}
        <label className="block space-y-1">
          <span className="label-ml">Meal</span>
          <input className="field-ml" placeholder="e.g. Paneer bhurji with roti" value={f.name} onChange={set("name")} aria-invalid={inv("name")} autoComplete="off" />
        </label>
        <div className="grid grid-cols-2 gap-2">
          <label className="block space-y-1">
            <span className="label-ml">Date</span>
            <input type="date" className="field-ml" value={f.date} onChange={set("date")} aria-invalid={inv("date")} />
          </label>
          <label className="block space-y-1">
            <span className="label-ml">Time</span>
            <input type="time" className="field-ml" value={f.time} onChange={set("time")} aria-invalid={inv("time")} />
          </label>
        </div>
        <div className="grid grid-cols-2 gap-2">
          {NUM_FIELDS.map(([k, label]) => (
            <label key={k} className={`block space-y-1 ${k === "calories" ? "col-span-2" : ""}`}>
              <span className="label-ml">{label}</span>
              <input
                inputMode="decimal" className="field-ml num" placeholder="0" value={f[k]}
                onChange={set(k)} aria-invalid={inv(k)}
              />
            </label>
          ))}
        </div>
        <label className="block space-y-1">
          <span className="label-ml">Notes (optional)</span>
          <textarea className="field-ml min-h-16" value={f.notes} onChange={set("notes")} rows={2} />
        </label>
        {tried && !valid && (
          <p className="text-sm text-destructive">Fill in the meal name and enter 0 or more for each nutrient.</p>
        )}
        {mismatch && (
          <p className="text-xs text-muted-foreground">
            Note: calories differ from a protein/carb/fat estimate. Your numbers are kept as entered.
          </p>
        )}
        <button type="submit" hidden />
        <div className="flex flex-wrap gap-2 pt-1">
          <button type="button" className="btn-ml btn-ghost text-sm" onClick={saveAsTemplate} disabled={savingTemplate}>{savingTemplate ? "Saving…" : "Save as reusable meal"}</button>
          {editing && (
            <p className="self-center text-xs text-muted-foreground">Use the trash icon beside this meal in your diary to delete it.</p>
          )}
        </div>
      </form>
    </Sheet>
  );
}

function blank(date: string): Form {
  return { name: "", date, time: nowTime(), notes: "", calories: "", protein: "", carbs: "", fat: "", fiber: "" };
}
