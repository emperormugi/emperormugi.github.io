import { ChevronLeft, ChevronRight } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { caloriesByDate } from "@/lib/macro/calc";
import { fromKey, monthGrid, todayKey } from "@/lib/macro/dates";
import type { Meal } from "@/lib/macro/types";
import { Sheet } from "./Sheet";

export function CalendarSheet({
  open, onOpenChange, meals, selected, onSelect,
}: {
  open: boolean; onOpenChange: (o: boolean) => void; meals: Meal[]; selected: string; onSelect: (d: string) => void;
}) {
  const [ym, setYm] = useState(() => { const d = fromKey(selected); return { y: d.getFullYear(), m: d.getMonth() }; });
  useEffect(() => { if (open) { const d = fromKey(selected); setYm({ y: d.getFullYear(), m: d.getMonth() }); } }, [open, selected]);
  const totals = useMemo(() => caloriesByDate(meals), [meals]);
  const today = todayKey();
  const weeks = monthGrid(ym.y, ym.m);
  const shift = (n: number) => setYm(({ y, m }) => { const d = new Date(y, m + n, 1); return { y: d.getFullYear(), m: d.getMonth() }; });
  const label = new Date(ym.y, ym.m, 1).toLocaleDateString(undefined, { month: "long", year: "numeric" });

  return (
    <Sheet open={open} onOpenChange={onOpenChange} title="Calendar">
      <div className="mb-3 flex items-center justify-between">
        <button className="icon-btn" onClick={() => shift(-1)} aria-label="Previous month"><ChevronLeft size={18} /></button>
        <div className="font-semibold">{label}</div>
        <button className="icon-btn" onClick={() => shift(1)} aria-label="Next month"><ChevronRight size={18} /></button>
      </div>
      <div className="grid grid-cols-7 gap-1 text-center text-[11px] text-muted-foreground">
        {["M", "T", "W", "T", "F", "S", "S"].map((d, i) => <div key={i} className="py-1">{d}</div>)}
      </div>
      <div className="grid grid-cols-7 gap-1">
        {weeks.flat().map((key, i) => {
          if (!key) return <div key={i} />;
          const kcal = totals.get(key);
          const isSel = key === selected;
          const isToday = key === today;
          return (
            <button
              key={key}
              onClick={() => { onSelect(key); onOpenChange(false); }}
              aria-label={`${fromKey(key).toDateString()}${kcal ? `, ${Math.round(kcal)} kcal` : ""}`}
              className={`flex h-14 flex-col items-center justify-center rounded-lg border text-sm transition-colors ${
                isSel ? "border-lime bg-lime text-lime-foreground" : isToday ? "border-lime/60 bg-surface" : "border-transparent bg-surface/50"
              }`}
            >
              <span className={`num font-medium ${isToday && !isSel ? "text-lime" : ""}`}>{fromKey(key).getDate()}</span>
              <span className={`num text-[10px] leading-tight ${isSel ? "" : kcal ? "text-foreground/80" : "text-muted-foreground/40"}`}>
                {kcal != null ? Math.round(kcal) : "·"}
              </span>
            </button>
          );
        })}
      </div>
      <button className="btn-ml btn-ghost mt-4 w-full" onClick={() => { onSelect(today); onOpenChange(false); }}>Go to today</button>
    </Sheet>
  );
}
