import { useState } from "react";
import { toast } from "sonner";
import { fmtG, fmtKcal } from "@/lib/macro/calc";
import { actions } from "@/lib/macro/store";
import type { Template } from "@/lib/macro/types";
import { Sheet } from "./Sheet";

export function SavedSheet({
  open, onOpenChange, templates, onUse,
}: {
  open: boolean; onOpenChange: (o: boolean) => void; templates: Template[]; onUse: (t: Template) => void;
}) {
  const [renaming, setRenaming] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [confirm, setConfirm] = useState<string | null>(null);
  const sorted = [...templates].sort((a, b) => a.name.localeCompare(b.name));

  return (
    <Sheet open={open} onOpenChange={onOpenChange} title="Saved meals">
      {sorted.length === 0 ? (
        <p className="py-8 text-center text-sm text-muted-foreground">
          No saved meals yet. When adding a meal, tap “Save as reusable meal”.
        </p>
      ) : (
        <ul className="space-y-2">
          {sorted.map((t) => (
            <li key={t.id} className="rounded-xl border border-border bg-surface p-3">
              {renaming === t.id ? (
                <form className="flex gap-2" onSubmit={async (e) => {
                  e.preventDefault();
                  if (!name.trim()) return;
                  try {
                    await actions.updateTemplate(t.id, { name: name.trim() });
                    setRenaming(null);
                    toast.success("Saved meal renamed");
                  } catch {
                    toast.error("Couldn't rename this saved meal. Please try again.");
                  }
                }}>
                  <input className="field-ml" value={name} onChange={(e) => setName(e.target.value)} autoFocus />
                  <button className="btn-ml btn-primary">Save</button>
                </form>
              ) : (
                <>
                  <div className="flex items-baseline justify-between gap-2">
                    <div className="font-medium">{t.name}</div>
                    <div className="num shrink-0 text-sm text-lime">{fmtKcal(t.calories)} kcal</div>
                  </div>
                  <div className="num mt-0.5 text-xs text-muted-foreground">
                    P {fmtG(t.protein)} · C {fmtG(t.carbs)} · F {fmtG(t.fat)} · Fi {fmtG(t.fiber)}
                  </div>
                  <div className="mt-2 flex gap-2">
                    <button className="btn-ml btn-primary !min-h-9 flex-1 text-sm" onClick={() => onUse(t)}>Use</button>
                    <button className="btn-ml btn-ghost !min-h-9 text-sm" onClick={() => { setRenaming(t.id); setName(t.name); }}>Rename</button>
                    {confirm === t.id ? (
                      <button className="btn-ml btn-danger !min-h-9 text-sm" onClick={async () => {
                        try {
                          await actions.deleteTemplate(t.id);
                          setConfirm(null);
                          toast.success("Saved meal removed");
                        } catch {
                          toast.error("Couldn't remove this saved meal. Please try again.");
                        }
                      }}>Confirm</button>
                    ) : (
                      <button className="btn-ml btn-danger !min-h-9 text-sm" onClick={() => setConfirm(t.id)}>Delete</button>
                    )}
                  </div>
                </>
              )}
            </li>
          ))}
        </ul>
      )}
    </Sheet>
  );
}
