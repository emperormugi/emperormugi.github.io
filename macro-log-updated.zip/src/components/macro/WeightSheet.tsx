import { useEffect, useState } from "react";
import { toast } from "sonner";
import { parseAmount, weightSummary } from "@/lib/macro/calc";
import { formatShort, isValidDateKey, todayKey } from "@/lib/macro/dates";
import { actions } from "@/lib/macro/store";
import type { WeightEntry } from "@/lib/macro/types";
import { Sheet } from "./Sheet";

export function WeightSheet({ open, onOpenChange, weights }: { open: boolean; onOpenChange: (o: boolean) => void; weights: WeightEntry[] }) {
  const [date, setDate] = useState(todayKey());
  const [kg, setKg] = useState("");
  const [editId, setEditId] = useState<string | undefined>();
  const [confirm, setConfirm] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState<string | null>(null);
  useEffect(() => { if (open) { setDate(todayKey()); setKg(""); setEditId(undefined); } }, [open]);

  const s = weightSummary(weights, todayKey());
  const recent = [...weights].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 30);
  const value = parseAmount(kg);
  const existing = weights.find((w) => w.date === date && w.id !== editId);

  const save = async () => {
    if (!value || value <= 0 || !isValidDateKey(date)) return toast.error("Enter a valid weight in kg.");
    if (saving) return;
    setSaving(true);
    try {
      await actions.saveWeight(date, value, editId);
      toast.success(existing ? "Weight for that day replaced" : "Weight saved");
      setKg(""); setEditId(undefined); setDate(todayKey());
    } catch {
      toast.error("Couldn't save this weight. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const removeWeight = async (id: string) => {
    if (deleting) return;
    setDeleting(id);
    try {
      await actions.deleteWeight(id);
      setConfirm(null);
      toast.success("Weight entry deleted");
    } catch {
      toast.error("Couldn't delete this weight entry. Please try again.");
    } finally {
      setDeleting(null);
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange} title="Weight">
      <div className="grid grid-cols-3 gap-2">
        <Stat label="Latest" value={s.latest ? `${s.latest.kg.toFixed(1)}` : "—"} sub={s.latest ? formatShort(s.latest.date) : "kg"} />
        <Stat label="7-day avg" value={s.thisWeek != null ? s.thisWeek.toFixed(1) : "—"} sub="kg" />
        <Stat label="vs prior week" value={s.change != null ? `${s.change > 0 ? "+" : ""}${s.change.toFixed(1)}` : "—"} sub="kg" />
      </div>
      {s.change == null && (
        <p className="mt-2 text-xs text-muted-foreground">Log weight in two consecutive weeks to see a weekly trend.</p>
      )}

      <form className="mt-4 space-y-2" onSubmit={(e) => { e.preventDefault(); save(); }}>
        <div className="grid grid-cols-2 gap-2">
          <label className="space-y-1"><span className="label-ml">Date</span>
            <input type="date" className="field-ml" value={date} onChange={(e) => setDate(e.target.value)} /></label>
          <label className="space-y-1"><span className="label-ml">Weight (kg)</span>
            <input inputMode="decimal" className="field-ml num" placeholder="72.4" value={kg} onChange={(e) => setKg(e.target.value)} /></label>
        </div>
        {existing && <p className="text-xs text-muted-foreground">One entry per day — saving replaces {existing.kg} kg on this date.</p>}
        <button className="btn-ml btn-primary w-full" disabled={saving}>{saving ? "Saving…" : editId ? "Save changes" : "Save weight"}</button>
      </form>

      <h3 className="label-ml mt-5 mb-2">Recent entries</h3>
      {recent.length === 0 ? (
        <p className="py-4 text-center text-sm text-muted-foreground">No weight entries yet.</p>
      ) : (
        <ul className="divide-y divide-border rounded-xl border border-border bg-surface">
          {recent.map((w) => (
            <li key={w.id} className="flex items-center justify-between gap-2 px-3 py-2.5">
              <span className="text-sm text-muted-foreground">{formatShort(w.date)}</span>
              <span className="num ml-auto font-medium">{w.kg.toFixed(1)} kg</span>
              <button className="px-2 text-sm text-lime" onClick={() => { setEditId(w.id); setDate(w.date); setKg(String(w.kg)); }}>Edit</button>
              {confirm === w.id ? (
                <button className="px-2 text-sm text-destructive" disabled={deleting === w.id} onClick={() => removeWeight(w.id)}>{deleting === w.id ? "Deleting…" : "Confirm"}</button>
              ) : (
                <button className="px-2 text-sm text-muted-foreground" onClick={() => setConfirm(w.id)}>Delete</button>
              )}
            </li>
          ))}
        </ul>
      )}
    </Sheet>
  );
}

function Stat({ label, value, sub }: { label: string; value: string; sub: string }) {
  return (
    <div className="rounded-xl border border-border bg-surface p-3">
      <div className="label-ml">{label}</div>
      <div className="num mt-1 text-xl font-semibold">{value}</div>
      <div className="text-[11px] text-muted-foreground">{sub}</div>
    </div>
  );
}
