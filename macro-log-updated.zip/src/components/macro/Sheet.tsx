import * as D from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import type { ReactNode } from "react";

export function Sheet({
  open,
  onOpenChange,
  title,
  children,
  footer,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  title: string;
  children: ReactNode;
  footer?: ReactNode;
}) {
  return (
    <D.Root open={open} onOpenChange={onOpenChange}>
      <D.Portal>
        <D.Overlay className="fixed inset-0 z-50 bg-background/70 backdrop-blur-sm data-[state=open]:animate-in data-[state=open]:fade-in-0" />
        <D.Content
          aria-describedby={undefined}
          className="fixed inset-x-0 bottom-0 z-50 mx-auto flex max-h-[92dvh] max-w-lg flex-col rounded-t-2xl border border-b-0 border-border bg-card data-[state=open]:animate-in data-[state=open]:slide-in-from-bottom-8"
        >
          <div className="flex items-center justify-between px-5 pb-2 pt-4">
            <D.Title className="text-lg font-semibold">{title}</D.Title>
            <D.Close className="icon-btn !h-9 !w-9" aria-label="Close">
              <X size={18} />
            </D.Close>
          </div>
          <div className="flex-1 overflow-y-auto px-5 pb-4">{children}</div>
          {footer && <div className="safe-bottom border-t border-border px-5 pt-3">{footer}</div>}
          {!footer && <div className="safe-bottom" />}
        </D.Content>
      </D.Portal>
    </D.Root>
  );
}
