import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { parseAmount, validateBackup } from "@/lib/macro/calc";
import { todayKey } from "@/lib/macro/dates";
import { actions, exportJson } from "@/lib/macro/store";
import type { AppData } from "@/lib/macro/types";
import { Sheet } from "./Sheet";

export function SettingsSheet({ open, onOpenChange, data }: { open: boolean; onOpenChange: (o: boolean) => void; data: AppData }) {
  const [target, setTarget] = useState("");
  const [pending, setPending] = useState<AppData | null>(null);
  const [savingTarget, setSavingTarget] = useState(false);
  const [restoring, setRestoring] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  useEffect(() => { if (open) { setTarget(String(data.settings.calorieTarget)); setPending(null); } }, [open, data.settings.calorieTarget]);

  const saveTarget = async () => {
    const n = parseAmount(target);
    if (!n || n <= 0) return toast.error("Enter a target above 0 kcal.");
    if (savingTarget) return;
    setSavingTarget(true);
    try {
      await actions.setTarget(Math.round(n));
      toast.success("Daily target saved");
    } catch {
      toast.error("Couldn't save your target. Please try again.");
    } finally {
      setSavingTarget(false);
    }
  };

  const doExport = async () => {
    try {
      const name = `macro-log-backup-${todayKey()}.json`;
      const file = new File([exportJson()], name, { type: "application/json" });
      // Share sheet / Files on iOS — the file is handed to iOS locally, never uploaded by the app.
      if (navigator.canShare?.({ files: [file] })) {
        try { await navigator.share({ files: [file], title: "Macro Log backup" }); } catch { /* user cancelled the share sheet */ }
        return;
      }
      const url = URL.createObjectURL(file);
      const a = document.createElement("a");
      a.href = url;
      a.download = name;
      a.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      toast.success("Backup prepared");
    } catch {
      toast.error("Couldn't export a backup on this device.");
    }
  };

  const pick = async (f: File | undefined) => {
    if (!f) return;
    try {
      const res = validateBackup(JSON.parse(await f.text()));
      if (!res.ok) return toast.error(res.error);
      setPending(res.data);
    } catch {
      toast.error("That file couldn't be read as a backup.");
    } finally {
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange} title="Settings">
      <section className="space-y-2">
        <h3 className="label-ml">Daily calorie target</h3>
        <div className="flex gap-2">
          <input inputMode="numeric" className="field-ml num" value={target} onChange={(e) => setTarget(e.target.value)} />
          <button className="btn-ml btn-primary" onClick={saveTarget} disabled={savingTarget}>{savingTarget ? "Saving…" : "Save"}</button>
        </div>
        <p className="text-xs text-muted-foreground">2,000 kcal is just a starting placeholder, not a recommendation.</p>
      </section>

      <section className="mt-6 space-y-2">
        <h3 className="label-ml">Backup & restore</h3>
        <p className="text-xs text-muted-foreground">
          {data.meals.length} meals · {data.templates.length} saved meals · {data.weights.length} weight entries
        </p>
        <div className="flex gap-2">
          <button className="btn-ml btn-ghost flex-1" onClick={doExport}>Export backup</button>
          <button className="btn-ml btn-ghost flex-1" onClick={() => fileRef.current?.click()} disabled={restoring}>Restore…</button>
          <input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={(e) => pick(e.target.files?.[0])} />
        </div>
        {pending && (
          <div className="rounded-xl border border-destructive/40 bg-surface p-3 text-sm">
            <p>
              Replace everything on this device with the backup ({pending.meals.length} meals, {pending.templates.length} saved
              meals, {pending.weights.length} weights)? Current data will be overwritten.
            </p>
            <div className="mt-2 flex gap-2">
              <button className="btn-ml btn-ghost flex-1" onClick={() => setPending(null)} disabled={restoring}>Cancel</button>
              <button className="btn-ml btn-danger flex-1" disabled={restoring} onClick={async () => {
                if (restoring || !pending) return;
                setRestoring(true);
                try {
                  await actions.replaceAll(pending);
                  setPending(null);
                  toast.success("Backup restored");
                } catch {
                  toast.error("Couldn't restore the backup. Your current data is still available.");
                } finally {
                  setRestoring(false);
                }
              }}>{restoring ? "Restoring…" : "Replace data"}</button>
            </div>
          </div>
        )}
      </section>

      <section className="mt-6 space-y-2 text-xs leading-relaxed text-muted-foreground">
        <h3 className="label-ml">Privacy</h3>
        <p>
          Every meal, note, target, saved meal and weight is stored only in this browser's storage on your iPhone. Macro Log
          has no account, no analytics, no cloud sync, and never sends your records over the network. The web host only
          serves the app's own files.
        </p>
        <p>
          Local data is lost if you delete the Home Screen app, clear Safari website data, or reset or lose your phone, and
          it may not be included in iCloud backups. Export a backup to Files regularly.
        </p>
      </section>
    </Sheet>
  );
}
