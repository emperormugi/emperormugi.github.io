import { Activity, AlertTriangle, BookmarkCheck, CalendarDays, Clock3, Flame, Pencil, Plus, RefreshCw, Scale, Settings, Trash2 } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { calorieStatus, dayTotals, fmtG, fmtKcal, loggingStreak, mealsForDate } from "@/lib/macro/calc";
import { addDays, formatLong, todayKey } from "@/lib/macro/dates";
import { actions, loadStore, useStore } from "@/lib/macro/store";
import type { Meal, Template } from "@/lib/macro/types";
import { CalendarSheet } from "./CalendarSheet";
import { MealForm } from "./MealForm";
import { SavedSheet } from "./SavedSheet";
import { SettingsSheet } from "./SettingsSheet";
import { WeightSheet } from "./WeightSheet";

type Panel = null | "meal" | "calendar" | "saved" | "weight" | "settings";

export function MacroApp() {
  const { ready, error, data } = useStore();
  const [today, setToday] = useState("");
  const [date, setDate] = useState("");
  const [panel, setPanel] = useState<Panel>(null);
  const [editing, setEditing] = useState<Meal | null>(null);
  const [prefill, setPrefill] = useState<Template | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Meal | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [retryingStorage, setRetryingStorage] = useState(false);

  useEffect(() => {
    loadStore();
    const t = todayKey();
    let lastKnownToday = t;
    setToday(t);
    setDate(t);
    // Roll over to the new day if the app stays open past midnight without nesting state updates.
    const onVis = () => {
      const n = todayKey();
      if (n === lastKnownToday) return;
      const previousDay = lastKnownToday;
      lastKnownToday = n;
      setToday(n);
      setDate((selectedDate) => selectedDate === previousDay ? n : selectedDate);
    };
    document.addEventListener("visibilitychange", onVis);
    const iv = setInterval(onVis, 60_000);
    return () => { document.removeEventListener("visibilitychange", onVis); clearInterval(iv); };
  }, []);

  const meals = useMemo(() => (date ? mealsForDate(data.meals, date) : []), [data.meals, date]);
  const totals = useMemo(() => dayTotals(data.meals, date), [data.meals, date]);
  const streak = useMemo(() => (today ? loggingStreak(data.meals, today) : 0), [data.meals, today]);
  const target = data.settings.calorieTarget;
  const st = calorieStatus(totals.calories, target);

  if (!ready || !date) return <div className="min-h-dvh bg-background" />;

  const retryStorage = async () => {
    if (retryingStorage) return;
    setRetryingStorage(true);
    try {
      await loadStore();
    } finally {
      setRetryingStorage(false);
    }
  };

  if (error) {
    return (
      <div className="mx-auto flex min-h-dvh max-w-lg items-center px-5 py-8">
        <section className="dashboard-card w-full p-5" role="alert">
          <span className="brand-mark mb-4"><AlertTriangle size={18} aria-hidden="true" /></span>
          <h1 className="font-display text-xl font-bold tracking-tight">Couldn't open your local log</h1>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            Macro Log couldn't read this device's saved data. To protect your existing entries, editing is paused until local storage opens successfully.
          </p>
          <p className="mt-2 text-xs text-muted-foreground">{error} If this keeps happening, avoid clearing browser data and restore a recent backup after storage is available.</p>
          <div className="mt-5 flex flex-col gap-2">
            <button className="btn-ml btn-primary w-full" disabled={retryingStorage} onClick={retryStorage}>
              <RefreshCw size={16} className={retryingStorage ? "animate-spin" : ""} aria-hidden="true" />
              {retryingStorage ? "Retrying…" : "Retry storage"}
            </button>
            <button className="btn-ml btn-ghost w-full" onClick={() => window.location.reload()}>Reload app</button>
          </div>
        </section>
      </div>
    );
  }

  const isToday = date === today;
  const openAdd = () => { setEditing(null); setPrefill(null); setPanel("meal"); };
  const openEdit = (meal: Meal) => { setEditing(meal); setPrefill(null); setPanel("meal"); };
  const removeMeal = async () => {
    if (!deleteTarget || deleting) return;
    setDeleting(true);
    try {
      await actions.deleteMeal(deleteTarget.id);
      toast.success(`Deleted “${deleteTarget.name}”`);
      setDeleteTarget(null);
    } catch {
      toast.error("Couldn't delete this meal. It's still in your log.");
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="mx-auto flex min-h-dvh max-w-lg flex-col bg-background">
      <header className="safe-top flex items-center justify-between px-5 pb-3">
        <div className="flex items-center gap-2.5">
          <span className="brand-mark" aria-hidden="true"><Activity size={18} strokeWidth={2.2} /></span>
          <div>
            <h1 className="font-display text-xl font-bold tracking-tight">Macro Log</h1>
            <p className="text-sm text-muted-foreground">{isToday ? "Today · " : ""}{formatLong(date)}</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button className="icon-btn" aria-label="Open calendar" onClick={() => setPanel("calendar")}><CalendarDays size={20} /></button>
          <button className="icon-btn" aria-label="Settings" onClick={() => setPanel("settings")}><Settings size={20} /></button>
        </div>
      </header>

      <main className="flex-1 space-y-3 px-5 pb-32">
        <section className="dashboard-card p-4" aria-label="Daily summary">
          <div className="flex items-end justify-between">
            <div>
              <div className="label-ml">Consumed</div>
              <div className="num font-display text-4xl font-bold text-lime">{fmtKcal(totals.calories)}</div>
              <div className="num text-xs text-muted-foreground">of {fmtKcal(target)} kcal</div>
            </div>
            <div className="text-right">
              <div className="label-ml">{st.isOver ? "Over target" : "Remaining"}</div>
              <div className={`num text-2xl font-semibold ${st.isOver ? "text-destructive" : ""}`}>
                {st.isOver ? "+" : ""}{fmtKcal(st.isOver ? st.over : st.remaining)}
              </div>
              <div className="text-xs text-muted-foreground">kcal</div>
            </div>
          </div>
          <div className="mt-3 h-2 overflow-hidden rounded-full bg-surface" role="progressbar" aria-valuenow={Math.round(st.progress * 100)} aria-valuemin={0} aria-valuemax={100}>
            <div className={`h-full rounded-full ${st.isOver ? "bg-destructive" : "bg-lime"}`} style={{ width: `${st.progress * 100}%` }} />
          </div>
          <div className="mt-4 grid grid-cols-4 gap-2">
            {([["Protein", totals.protein], ["Carbs", totals.carbs], ["Fat", totals.fat], ["Fiber", totals.fiber]] as const).map(([l, v]) => (
              <div key={l} className="rounded-lg bg-surface px-2 py-2 text-center">
                <div className="num text-base font-semibold">{fmtG(v)}<span className="text-xs text-muted-foreground">g</span></div>
                <div className="text-[11px] text-muted-foreground">{l}</div>
              </div>
            ))}
          </div>
        </section>

        <div className="flex gap-2">
          <div className="card-ml flex flex-1 items-center gap-2 px-3 py-2.5 text-sm">
            <Flame size={16} className="text-lime" />
            <span className="num font-semibold">{streak}</span>
            <span className="text-muted-foreground">day streak</span>
          </div>
          <button className="card-ml flex items-center gap-1.5 px-3 text-sm" onClick={() => setPanel("saved")}><BookmarkCheck size={16} /> Saved</button>
          <button className="card-ml flex items-center gap-1.5 px-3 text-sm" onClick={() => setPanel("weight")}><Scale size={16} /> Weight</button>
        </div>

        <section aria-label="Meals">
          <div className="mb-2 mt-2 flex items-center justify-between">
            <h2 className="label-ml">Meals · {meals.length}</h2>
            {!isToday && <button className="text-xs text-lime" onClick={() => setDate(today)}>Back to today</button>}
          </div>
          {meals.length === 0 ? (
            <div className="card-ml px-4 py-10 text-center text-sm text-muted-foreground">
              Nothing logged {isToday ? "today" : "on this day"} yet.
            </div>
          ) : (
            <ul className="space-y-2.5">
              {meals.map((m) => (
                <li key={m.id} className="meal-card">
                  <div className="flex items-stretch gap-2.5 p-3">
                    <button
                      type="button"
                      className="min-w-0 flex-1 rounded-lg text-left outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      onClick={() => openEdit(m)}
                      aria-label={`Open ${m.name} to edit`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="inline-flex items-center gap-1.5 rounded-full bg-surface px-2 py-1 text-[11px] text-muted-foreground">
                          <Clock3 size={12} aria-hidden="true" />
                          <span className="num">{m.time}</span>
                        </span>
                        <span className="num shrink-0 font-semibold text-lime">
                          {fmtKcal(m.calories)} <span className="text-[11px] font-medium text-muted-foreground">kcal</span>
                        </span>
                      </div>
                      <div className="mt-2 truncate text-[15px] font-semibold leading-snug tracking-tight">{m.name}</div>
                      <div className="num mt-1.5 text-[11px] leading-relaxed text-muted-foreground">
                        P {fmtG(m.protein)}g <span className="mx-0.5 text-border">·</span> C {fmtG(m.carbs)}g <span className="mx-0.5 text-border">·</span> F {fmtG(m.fat)}g <span className="mx-0.5 text-border">·</span> Fi {fmtG(m.fiber)}g
                      </div>
                      {m.notes && <div className="mt-1.5 line-clamp-2 text-xs leading-relaxed text-muted-foreground/80">{m.notes}</div>}
                    </button>
                    <div className="flex shrink-0 flex-col justify-center gap-1.5 border-l border-border/70 pl-2">
                      <button
                        type="button"
                        className="meal-action"
                        aria-label={`Edit ${m.name}`}
                        title="Edit meal"
                        onClick={() => openEdit(m)}
                      ><Pencil size={15} aria-hidden="true" /></button>
                      <button
                        type="button"
                        className="meal-action meal-action-danger"
                        aria-label={`Delete ${m.name}`}
                        title="Delete meal"
                        onClick={() => setDeleteTarget(m)}
                      ><Trash2 size={15} aria-hidden="true" /></button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
          <div className="mt-3 flex justify-between text-xs text-muted-foreground">
            <button className="py-2" onClick={() => setDate(addDays(date, -1))}>← Previous day</button>
            {!isToday && <button className="py-2" onClick={() => setDate(addDays(date, 1))}>Next day →</button>}
          </div>
        </section>
      </main>

      <div className="safe-bottom fixed inset-x-0 bottom-0 z-40 mx-auto max-w-lg bg-gradient-to-t from-background via-background to-transparent px-5 pt-6">
        <button className="btn-ml btn-primary h-14 w-full text-base" onClick={openAdd}>
          <Plus size={20} /> Add Meal{!isToday ? ` · ${formatLong(date).split(",")[0]}` : ""}
        </button>
      </div>

      <MealForm
        open={panel === "meal"} onOpenChange={(o) => setPanel(o ? "meal" : null)}
        date={date} editing={editing} prefill={editing ? null : prefill} templates={data.templates}
        onDateSaved={(d) => setDate(d)}
      />
      <CalendarSheet open={panel === "calendar"} onOpenChange={(o) => setPanel(o ? "calendar" : null)} meals={data.meals} selected={date} onSelect={setDate} />
      <SavedSheet
        open={panel === "saved"} onOpenChange={(o) => setPanel(o ? "saved" : null)} templates={data.templates}
        onUse={(t) => { setEditing(null); setPrefill(t); setPanel("meal"); }}
      />
      <WeightSheet open={panel === "weight"} onOpenChange={(o) => setPanel(o ? "weight" : null)} weights={data.weights} />
      <SettingsSheet open={panel === "settings"} onOpenChange={(o) => setPanel(o ? "settings" : null)} data={data} />

      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => { if (!open && !deleting) setDeleteTarget(null); }}>
        <AlertDialogContent className="rounded-2xl border-border bg-card">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this meal?</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteTarget ? `“${deleteTarget.name}” will be permanently removed from your log. Your daily totals and calendar will update automatically.` : "This meal will be removed from your log."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting} className="rounded-xl">Keep meal</AlertDialogCancel>
            <button type="button" className="btn-ml btn-danger" onClick={removeMeal} disabled={deleting}>
              <Trash2 size={16} aria-hidden="true" /> {deleting ? "Deleting…" : "Delete meal"}
            </button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
