import { describe, expect, it } from "vitest";
import { calorieStatus, dayTotals, loggingStreak, mealsForDate, parseAmount, validateBackup } from "./calc";
import { addDays, monthGrid, toKey } from "./dates";
import type { Meal } from "./types";

const meal = (date: string, time: string, calories: number, protein = 0): Meal => ({
  id: `${date}-${time}`, date, time, name: "m", notes: "", calories, protein, carbs: 0, fat: 0, fiber: 0,
  createdAt: 0, updatedAt: 0,
});

describe("daily totals", () => {
  it("sums only meals on the selected date", () => {
    const meals = [meal("2026-10-28", "08:00", 400, 30.5), meal("2026-10-28", "13:00", 650, 4), meal("2026-10-27", "20:00", 900)];
    expect(dayTotals(meals, "2026-10-28")).toMatchObject({ calories: 1050, protein: 34.5 });
    expect(dayTotals(meals, "2026-10-27").calories).toBe(900);
  });
  it("orders meals chronologically", () => {
    const meals = [meal("2026-10-28", "19:00", 1), meal("2026-10-28", "07:30", 1)];
    expect(mealsForDate(meals, "2026-10-28").map((m) => m.time)).toEqual(["07:30", "19:00"]);
  });
});

describe("calorie status", () => {
  it("shows amount over target and caps the bar at 100%", () => {
    expect(calorieStatus(2300, 2000)).toMatchObject({ over: 300, remaining: 0, isOver: true, progress: 1 });
    expect(calorieStatus(1500, 2000)).toMatchObject({ remaining: 500, isOver: false, progress: 0.75 });
  });
});

describe("logging streak", () => {
  const today = "2026-10-28";
  it("keeps the streak ending yesterday when today is empty", () => {
    expect(loggingStreak([meal("2026-10-27", "08:00", 1), meal("2026-10-26", "08:00", 1)], today)).toBe(2);
  });
  it("stops at a gap", () => {
    expect(loggingStreak([meal(today, "08:00", 1), meal("2026-10-26", "08:00", 1)], today)).toBe(1);
  });
  it("is zero with no logs", () => expect(loggingStreak([], today)).toBe(0));
});

describe("number input", () => {
  it("accepts decimals and rejects negatives/garbage", () => {
    expect(parseAmount("34.5")).toBe(34.5);
    expect(parseAmount("34,5")).toBe(34.5);
    expect(parseAmount("-3")).toBeNull();
    expect(parseAmount("abc")).toBeNull();
    expect(parseAmount("")).toBeNull();
  });
});

describe("local dates", () => {
  it("crosses month boundaries", () => expect(addDays("2026-03-01", -1)).toBe("2026-02-28"));
  it("uses local date components", () => expect(toKey(new Date(2026, 0, 1, 23, 59))).toBe("2026-01-01"));
  it("builds a month grid with every day", () => expect(monthGrid(2026, 1).flat().filter(Boolean)).toHaveLength(28));
});

describe("backup validation", () => {
  it("rejects foreign files and negative values", () => {
    expect(validateBackup({ foo: 1 }).ok).toBe(false);
    expect(validateBackup({ app: "macro-log", version: 1, meals: [{ ...meal("2026-10-28", "08:00", -5) }], templates: [], weights: [] }).ok).toBe(false);
  });
  it("accepts a valid backup", () => {
    expect(validateBackup({ app: "macro-log", version: 1, meals: [meal("2026-10-28", "08:00", 5)], templates: [], weights: [], settings: { calorieTarget: 2200 } }).ok).toBe(true);
  });
  it("rejects duplicate meal IDs and more than one weight per date", () => {
    const m = meal("2026-10-28", "08:00", 5);
    expect(validateBackup({ app: "macro-log", version: 1, meals: [m, { ...m, time: "09:00" }], templates: [], weights: [] }))
      .toMatchObject({ ok: false, error: "Backup contains duplicate meal IDs." });
    expect(validateBackup({ app: "macro-log", version: 1, meals: [], templates: [], weights: [
      { id: "w1", date: "2026-10-28", kg: 70 },
      { id: "w2", date: "2026-10-28", kg: 71 },
    ] })).toMatchObject({ ok: false, error: "Backup contains more than one weight entry for a date." });
  });
});
