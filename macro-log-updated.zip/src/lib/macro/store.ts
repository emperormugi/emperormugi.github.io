import { useSyncExternalStore } from "react";
import { DEFAULT_DATA, type AppData, type Meal, type Template, type WeightEntry } from "./types";

// Local-only persistence in IndexedDB. Nothing here ever touches the network.
const DB_NAME = "macro-log";
const STORE = "kv";
const KEY = "data";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
    };
    req.onsuccess = () => {
      req.result.onversionchange = () => req.result.close();
      resolve(req.result);
    };
    req.onerror = () => reject(req.error ?? new Error("Unable to open local database"));
    req.onblocked = () => reject(new Error("Local database upgrade is blocked by another open tab"));
  });
}

async function readData(): Promise<AppData> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    let result: AppData | undefined;
    let settled = false;
    const close = () => db.close();
    const fail = (error: DOMException | null) => {
      if (settled) return;
      settled = true;
      close();
      reject(error ?? new Error("Unable to read local data"));
    };
    try {
      const tx = db.transaction(STORE, "readonly");
      const req = tx.objectStore(STORE).get(KEY);
      req.onsuccess = () => { result = req.result as AppData | undefined; };
      req.onerror = () => fail(req.error);
      tx.oncomplete = () => {
        if (settled) return;
        settled = true;
        close();
        resolve(result ?? DEFAULT_DATA);
      };
      tx.onerror = () => fail(tx.error);
      tx.onabort = () => fail(tx.error);
    } catch (error) {
      if (!settled) {
        settled = true;
        close();
        reject(error);
      }
    }
  });
}

async function writeData(data: AppData): Promise<void> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    let settled = false;
    const close = () => db.close();
    const fail = (error: DOMException | null) => {
      if (settled) return;
      settled = true;
      close();
      reject(error ?? new Error("Unable to save local data"));
    };
    try {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).put(data, KEY);
      tx.oncomplete = () => {
        if (settled) return;
        settled = true;
        close();
        resolve();
      };
      tx.onerror = () => fail(tx.error);
      tx.onabort = () => fail(tx.error);
    } catch (error) {
      if (!settled) {
        settled = true;
        close();
        reject(error);
      }
    }
  });
}

type State = { ready: boolean; error: string | null; data: AppData };
let state: State = { ready: false, error: null, data: DEFAULT_DATA };
const listeners = new Set<() => void>();
const emit = () => listeners.forEach((l) => l());

let loading: Promise<void> | null = null;
export function loadStore() {
  if (loading) return loading;
  loading = (async () => {
    try {
      const data = await readData();
      state = { ready: true, error: null, data };
      if (navigator.storage?.persist) navigator.storage.persist().catch(() => {});
    } catch {
      state = { ...state, ready: true, error: "Could not open local storage on this device." };
      // Allow the UI to retry after a transient IndexedDB/browser storage problem.
      loading = null;
    }
    emit();
  })();
  return loading;
}

/** Persist first, then update UI. Serialize writes to prevent rapid actions from losing updates. */
type AppDataUpdate = AppData | ((current: AppData) => AppData);
let writeQueue: Promise<void> = Promise.resolve();

function commit(update: AppDataUpdate): Promise<void> {
  const task = writeQueue.then(async () => {
    const next = typeof update === "function" ? update(state.data) : update;
    await writeData(next);
    state = { ...state, data: next };
    emit();
  });
  // A failed write must be reported to its caller but must not block future attempts.
  writeQueue = task.catch(() => undefined);
  return task;
}

const uid = () =>
  typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;

const SERVER_STATE: State = { ready: false, error: null, data: DEFAULT_DATA };
export function useStore(): State {
  return useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => listeners.delete(l);
    },
    () => state,
    () => SERVER_STATE,
  );
}

export type MealInput = Omit<Meal, "id" | "createdAt" | "updatedAt">;
export type TemplateInput = Omit<Template, "id" | "createdAt">;

export const actions = {
  addMeal: (m: MealInput) => {
    const now = Date.now();
    const meal: Meal = { ...m, id: uid(), createdAt: now, updatedAt: now };
    return commit((current) => ({ ...current, meals: [...current.meals, meal] }));
  },
  updateMeal: (id: string, m: MealInput) =>
    commit((current) => ({
      ...current,
      meals: current.meals.map((x) => (x.id === id ? { ...x, ...m, updatedAt: Date.now() } : x)),
    })),
  deleteMeal: (id: string) =>
    commit((current) => ({ ...current, meals: current.meals.filter((x) => x.id !== id) })),

  addTemplate: (t: TemplateInput) => {
    const template: Template = { ...t, id: uid(), createdAt: Date.now() };
    return commit((current) => ({ ...current, templates: [...current.templates, template] }));
  },
  updateTemplate: (id: string, t: Partial<TemplateInput>) =>
    commit((current) => ({
      ...current,
      templates: current.templates.map((x) => (x.id === id ? { ...x, ...t } : x)),
    })),
  deleteTemplate: (id: string) =>
    commit((current) => ({ ...current, templates: current.templates.filter((x) => x.id !== id) })),

  /** One weight per date: saving on an existing date replaces that day's value. */
  saveWeight: (date: string, kg: number, id?: string) => {
    const entry: WeightEntry = { id: id ?? uid(), date, kg };
    return commit((current) => ({
      ...current,
      weights: [...current.weights.filter((w) => w.date !== date && w.id !== id), entry],
    }));
  },
  deleteWeight: (id: string) =>
    commit((current) => ({ ...current, weights: current.weights.filter((w) => w.id !== id) })),

  setTarget: (calorieTarget: number) =>
    commit((current) => ({ ...current, settings: { ...current.settings, calorieTarget } })),
  replaceAll: (data: AppData) => commit(data),
};

export function exportJson(): string {
  return JSON.stringify({ app: "macro-log", exportedAt: new Date().toISOString(), ...state.data }, null, 2);
}
