export type Nutrients = {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
};

export type Meal = Nutrients & {
  id: string;
  /** Local calendar date, YYYY-MM-DD */
  date: string;
  /** Local time, HH:mm (24h) */
  time: string;
  name: string;
  notes: string;
  createdAt: number;
  updatedAt: number;
};

export type Template = Nutrients & {
  id: string;
  name: string;
  notes: string;
  createdAt: number;
};

export type WeightEntry = {
  id: string;
  date: string;
  kg: number;
};

export type Settings = {
  calorieTarget: number;
};

export type AppData = {
  version: 1;
  meals: Meal[];
  templates: Template[];
  weights: WeightEntry[];
  settings: Settings;
};

export const DEFAULT_DATA: AppData = {
  version: 1,
  meals: [],
  templates: [],
  weights: [],
  settings: { calorieTarget: 2000 },
};
