import { addDays, isValidDateKey, isValidTime } from "./dates";
import type { AppData, Meal, Nutrients, WeightEntry } from "./types";

export const ZERO: Nutrients = { calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 };

export function sumNutrients(items: Nutrients[]): Nutrients {
  return items.reduce(
    (t, m) => ({
      calories: t.calories + m.calories,
      protein: t.protein + m.protein,
      carbs: t.carbs + m.carbs,
      fat: t.fat + m.fat,
      fiber: t.fiber + m.fiber,
    }),
    { ...ZERO },
  );
}

export function mealsForDate(meals: Meal[], date: string): Meal[] {
  return meals
    .filter((m) => m.date === date)
    .sort((a, b) => a.time.localeCompare(b.time) || a.createdAt - b.createdAt);
}

export function dayTotals(meals: Meal[], date: string): Nutrients {
  return sumNutrients(meals.filter((m) => m.date === date));
}

export function caloriesByDate(meals: Meal[]): Map<string, number> {
  const map = new Map<string, number>();
  for (const m of meals) map.set(m.date, (map.get(m.date) ?? 0) + m.calories);
  return map;
}

export function calorieStatus(consumed: number, target: number) {
  const diff = target - consumed;
  return {
    remaining: Math.max(0, diff),
    over: Math.max(0, -diff),
    isOver: diff < 0,
    progress: target > 0 ? Math.min(1, Math.max(0, consumed / target)) : 0,
  };
}

/** Consecutive logged days ending today, or ending yesterday if today has nothing yet. */
export function loggingStreak(meals: Meal[], today: string): number {
  const days = new Set(meals.map((m) => m.date));
  let cursor = days.has(today) ? today : addDays(today, -1);
  let count = 0;
  while (days.has(cursor)) {
    count++;
    cursor = addDays(cursor, -1);
  }
  return count;
}

/** Subtle hint when entered calories differ a lot from 4/4/9 estimate. Never modifies data. */
export function macroMismatch(n: Nutrients): boolean {
  const est = n.protein * 4 + n.carbs * 4 + n.fat * 9;
  if (n.calories < 50 && est < 50) return false;
  return Math.abs(est - n.calories) > Math.max(80, n.calories * 0.25);
}

export function weightSummary(weights: WeightEntry[], today: string) {
  const sorted = [...weights].sort((a, b) => a.date.localeCompare(b.date));
  const latest = sorted.at(-1) ?? null;
  const avg = (from: string, to: string) => {
    const xs = sorted.filter((w) => w.date >= from && w.date <= to).map((w) => w.kg);
    return xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null;
  };
  const thisWeek = avg(addDays(today, -6), today);
  const lastWeek = avg(addDays(today, -13), addDays(today, -7));
  return {
    latest,
    thisWeek,
    lastWeek,
    change: thisWeek != null && lastWeek != null ? thisWeek - lastWeek : null,
  };
}

/** Parse a user-typed number. Returns null if empty/invalid/negative. */
export function parseAmount(raw: string): number | null {
  const s = raw.trim().replace(",", ".");
  if (s === "" || !/^\d*\.?\d+$|^\d+\.$/.test(s)) return null;
  const n = Number(s);
  return Number.isFinite(n) && n >= 0 ? n : null;
}

export const fmtKcal = (n: number) => Math.round(n).toLocaleString();
export const fmtG = (n: number) => (Math.round(n * 10) / 10).toString();

// ---------- Backup validation ----------
const isNum = (v: unknown) => typeof v === "number" && Number.isFinite(v) && v >= 0;
const isStr = (v: unknown) => typeof v === "string";
const nutrientsOk = (o: Record<string, unknown>) =>
  ["calories", "protein", "carbs", "fat", "fiber"].every((k) => isNum(o[k]));

export function validateBackup(raw: unknown): { ok: true; data: AppData } | { ok: false; error: string } {
  if (!raw || typeof raw !== "object") return { ok: false, error: "File is not a Macro Log backup." };
  const r = raw as Record<string, unknown>;
  if (r.app !== "macro-log" || r.version !== 1) return { ok: false, error: "Unrecognised backup format." };
  const { meals, templates, weights, settings } = r as Record<string, unknown>;
  if (!Array.isArray(meals) || !Array.isArray(templates) || !Array.isArray(weights))
    return { ok: false, error: "Backup is missing data sections." };
  const mealIds = new Set<string>();
  for (const m of meals as Record<string, unknown>[]) {
    if (!m || !isStr(m.id) || !m.id || !isStr(m.name) || !m.name.trim() || !isValidDateKey(m.date) || !isValidTime(m.time) || !nutrientsOk(m))
      return { ok: false, error: "Backup contains an invalid meal entry." };
    if (mealIds.has(m.id)) return { ok: false, error: "Backup contains duplicate meal IDs." };
    mealIds.add(m.id);
  }
  const templateIds = new Set<string>();
  for (const t of templates as Record<string, unknown>[]) {
    if (!t || !isStr(t.id) || !t.id || !isStr(t.name) || !t.name.trim() || !nutrientsOk(t))
      return { ok: false, error: "Backup contains an invalid saved meal." };
    if (templateIds.has(t.id)) return { ok: false, error: "Backup contains duplicate saved-meal IDs." };
    templateIds.add(t.id);
  }
  const weightIds = new Set<string>();
  const weightDates = new Set<string>();
  for (const w of weights as Record<string, unknown>[]) {
    if (!w || !isStr(w.id) || !w.id || !isValidDateKey(w.date) || !isNum(w.kg) || (w.kg as number) <= 0)
      return { ok: false, error: "Backup contains an invalid weight entry." };
    if (weightIds.has(w.id)) return { ok: false, error: "Backup contains duplicate weight IDs." };
    if (weightDates.has(w.date as string)) return { ok: false, error: "Backup contains more than one weight entry for a date." };
    weightIds.add(w.id);
    weightDates.add(w.date as string);
  }
  const s = settings as Record<string, unknown> | undefined;
  const target = s && isNum(s.calorieTarget) && (s.calorieTarget as number) > 0 ? (s.calorieTarget as number) : 2000;
  return {
    ok: true,
    data: {
      version: 1,
      meals: (meals as Meal[]).map((m) => ({
        ...m,
        notes: isStr(m.notes) ? m.notes : "",
        createdAt: isNum(m.createdAt) ? m.createdAt : Date.now(),
        updatedAt: isNum(m.updatedAt) ? m.updatedAt : Date.now(),
      })),
      templates: (templates as AppData["templates"]).map((t) => ({
        ...t,
        notes: isStr(t.notes) ? t.notes : "",
        createdAt: isNum(t.createdAt) ? t.createdAt : Date.now(),
      })),
      weights: weights as WeightEntry[],
      settings: { calorieTarget: target },
    },
  };
}
