import { createFileRoute } from "@tanstack/react-router";
import { MacroApp } from "@/components/macro/MacroApp";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Macro Log — Private offline nutrition diary" },
      { name: "description", content: "Log meals, calories and macros on your iPhone. Works offline; data never leaves your device." },
      { property: "og:title", content: "Macro Log — Private offline nutrition diary" },
      { property: "og:description", content: "Log meals, calories and macros on your iPhone. Works offline; data never leaves your device." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: MacroApp,
});
