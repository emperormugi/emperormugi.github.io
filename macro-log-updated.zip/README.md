# Macro Log

Macro Log is a private, mobile-first nutrition diary built with React, TypeScript, TanStack Start, and Tailwind CSS. It is designed for iPhone use and keeps meal, weight, and settings data in local IndexedDB storage in the browser. The app does not require an account or a cloud database.

## Features

- Daily calories, protein, carbohydrates, fat, and fiber totals
- Editable calorie target and remaining/over-target indicator
- Monthly calendar with logged calorie totals per day
- Meal entries with date, time, nutrients, and notes
- Explicit edit and delete actions for each meal, including a confirmation step before deletion
- Reusable saved meals
- Logging streak and weekly weight tracking
- JSON backup export and restore
- Dark theme with subtle lime accents
- Progressive Web App support for installation and offline use after the app has been loaded and its service worker has cached the required files

## Privacy and long-term data safety

Meal records and settings are stored locally in IndexedDB for the current browser origin. The app code does not send user records to a server and does not include an account, analytics, or cloud sync. The web host serves the app files; it does not receive meal records through this app's storage layer.

Local storage is not a substitute for a backup. Clearing Safari website data, removing the installed web app, changing to a different website origin, or losing the device can make the local records unavailable. Use **Settings → Export backup** periodically and keep the JSON backup somewhere safe. Restoring a backup replaces the data currently stored on that device.

## Run locally

Requires Node.js and npm. The repository also includes `bun.lock` for Bun users.

```sh
npm install
npm run dev
```

## Checks

```sh
npm run test
npm run lint
npm run build
```

## Install on iPhone

Deploy the app to an HTTPS host, open the deployed site in Safari on the iPhone, then use Safari's **Share → Add to Home Screen**. Open the app once while online so the service worker can cache its assets. Offline availability depends on the browser having successfully cached the app shell and the device retaining that cache.
